package itying.com.flutter_jdshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
